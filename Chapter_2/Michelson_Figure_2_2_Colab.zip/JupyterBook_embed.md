Copy `MichelsonOverlay.mp4` to `_static/videos/` and `MichelsonOverlay_final.png` to `_static/images/`.

Python cell:

```python
from IPython.display import HTML
from myst_nb import glue

michelson_video = HTML(r"""
<video
    src="../_static/videos/MichelsonOverlay.mp4"
    poster="../_static/images/MichelsonOverlay_final.png"
    controls
    loop
    playsinline
    preload="metadata"
    width="100%"
    style="max-width: 1200px; display: block; margin: auto;"
    aria-label="Two views of a Michelson interferometer. Light passes through a source diffuser to a beam splitter, travels to two perpendicular mirrors, returns to the splitter, and recombines toward a screen. Teal and red distinguish the two optical paths, not wavelengths.">
    Your browser does not support the HTML5 video element.
</video>
""")

glue("michelson-interferometer-video", michelson_video, display=False)
```

Markdown cell (preserves the existing Figure 2.2 cross-reference label):

````markdown
```{glue:figure} michelson-interferometer-video
:name: interferometer-fig
:align: center

**Michelson interferometer.** (a) Apparatus and (b) plan view. The beam splitter $M$ directs light toward mirrors $M_1$ and $M_2$; the returning beams recombine toward the screen. $S$ is the source diffuser, and $C$ compensates for the unequal glass thickness traversed by the two paths. Colors distinguish paths, not wavelengths; output rays are separated slightly for visibility. Realistic illustration and animation based on [OpenStax University Physics, Volume 3, Figure 3.16](https://openstax.org/books/university-physics-volume-3/pages/3-5-the-michelson-interferometer).
```
````

Static-image alternative (use this instead of, not alongside, the video block with the same label):

````markdown
```{figure-md} interferometer-fig
<img src="../_static/images/MichelsonOverlay_final.png" alt="Realistic apparatus and plan view of a Michelson interferometer, with labeled components and arrows tracing both outgoing and returning light paths." style="max-width:100%; height:auto;">

**Michelson interferometer.** (a) Apparatus and (b) plan view. Light splits at $M$, reflects from $M_1$ and $M_2$, and recombines toward the screen. $S$ is the source diffuser, and $C$ is the compensator. Colors identify paths, not wavelengths. Realistic illustration based on [OpenStax University Physics, Volume 3, Figure 3.16](https://openstax.org/books/university-physics-volume-3/pages/3-5-the-michelson-interferometer).
```
````

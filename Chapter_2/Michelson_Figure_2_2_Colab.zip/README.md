# Michelson interferometer — Figure 2.2

The clean background and all annotation anchors use the same 2172 × 724 pixel coordinate system. Manim adds white space above and below it, producing a 2172 × 1020 figure. Labels, arrows, leaders, and dimensions remain editable vector objects in the source.

## Files

- `Michelson_background.png`: clean, realistic background without labels or beams.
- `michelson_overlay.py`: static and animated Manim scenes.
- `Michelson_Colab.ipynb`: Colab cells to write the source, render the movie and poster, and display them. Upload the background into the notebook's working directory before rendering. Manim must already be installed.
- `MichelsonOverlay_final.png`: annotated static figure and video poster, generated when you run the notebook.
- `MichelsonOverlay.mp4`: animated overlay, generated when you run the notebook.
- `JupyterBook_embed.md`: Python glue cell and figure block, including the poster and original `interferometer-fig` label.

## Render in an existing Colab Manim environment

Keep the Python file and background beside each other. Run:

```python
!manim -qh --renderer cairo --fps 30 --resolution 2172,1020 --disable_caching --media_dir media michelson_overlay.py MichelsonOverlay
!manim -qh --renderer cairo --resolution 2172,1020 --disable_caching --media_dir media -s -o MichelsonOverlay_final michelson_overlay.py MichelsonFigure
```

The movie is `media/videos/michelson_overlay/1020p30/MichelsonOverlay.mp4`. The poster is `media/images/michelson_overlay/MichelsonOverlay_final.png`.

## Optical conventions

- Incident light reaches the beam splitter from the laser through the diffuser.
- The teal path is initially reflected toward M₁. Its return passes through M toward the screen.
- The red path is initially transmitted toward M₂ through C. Its return passes through C again and is reflected by M toward the screen.
- Both output paths point toward the screen. Their slight drawing separation is only for visibility; they overlap physically.
- The unused return port toward the source is omitted for clarity.
- `d₁` and `d₂` are one-way arm distances from the splitter crossing to the reflecting mirror faces; the drawing is not to scale.
- Staged dots identify ray routes. They are not a simulation of relative travel time, phase, intensity, fringes, or the historical ether prediction.

## Background and source

The background is an AI-generated realistic illustration, not a photograph of an actual instrument. Its layout is based on [OpenStax University Physics Volume 3, Figure 3.16](https://openstax.org/books/university-physics-volume-3/pages/3-5-the-michelson-interferometer). The labels and optical-path overlay are constructed in Manim.

## Verification status

The source passes Python syntax checking. Beam directions, component anchors, and dimension endpoints were reviewed against the clean background and the reference layout. The scene has not been rendered here; check text spacing and final appearance in your Colab environment.

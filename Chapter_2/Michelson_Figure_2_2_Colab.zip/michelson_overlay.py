"""Figure 2.2: deterministic Manim annotations on the realistic background.

Keep Michelson_background.png beside this file. Render with Cairo.
All anchor coordinates below are pixels in the original 2172 x 724 image.
"""
from pathlib import Path
from manim import *
import numpy as np


config.frame_width = 21.72
config.frame_height = 10.20
config.background_color = WHITE

BACKGROUND = Path(__file__).with_name("Michelson_background.png")
INK = "#172B3A"
TEAL = "#008C95"
RED_PATH = "#D23B40"
INCIDENT = "#D28A00"
IMAGE_TOP = 120
SCALE = 100

# Source aperture, beam-splitter crossing, mirror faces, and receiving screen.
PANELS = [
    dict(source=(208, 262), splitter=(493, 335), m1=(740, 91), m2=(815, 417), screen=(319, 507)),
    dict(source=(1456, 365), splitter=(1769, 365), m1=(1769, 151), m2=(2088, 365), screen=(1769, 588)),
]


def canvas_point(x, y):
    return np.array([(x - 1086) / SCALE, (510 - y) / SCALE, 0.0])


def image_point(pair):
    return canvas_point(pair[0], pair[1] + IMAGE_TOP)


def caption(text, x, y, size=27, color=INK, backing=False):
    label = Text(text, font="DejaVu Sans", font_size=size, color=color).move_to(canvas_point(x, y))
    if backing:
        panel = SurroundingRectangle(label, color=WHITE, fill_color=WHITE, fill_opacity=0.94, stroke_width=0, buff=0.06)
        return VGroup(panel, label).set_z_index(6)
    return label.set_z_index(6)


def component_label(text, location, target, size=27):
    label = caption(text, location[0], location[1] + IMAGE_TOP, size=size, backing=True)
    anchor = image_point(target)
    start = label.get_boundary_point(anchor - label.get_center())
    halo = Line(start, anchor, color=WHITE, stroke_width=4.5)
    leader = Line(start, anchor, color=INK, stroke_width=1.8)
    return VGroup(halo, leader, label).set_z_index(6)


def ray_line(start, end, color):
    halo = Line(start, end, color=WHITE, stroke_width=7)
    core = Line(start, end, color=color, stroke_width=3.5)
    return VGroup(halo, core).set_z_index(3)


def direction_arrow(start, end, fraction, color, forward=True):
    unit = (end - start) / np.linalg.norm(end - start)
    center = start + fraction * (end - start)
    direction = unit if forward else -unit
    arrow = Arrow(center - 0.20 * direction, center + 0.20 * direction, buff=0, color=color, stroke_width=3.5, tip_length=0.13, max_tip_length_to_length_ratio=0.5)
    return arrow.set_z_index(4)


def dimension(start, end, text, label_position):
    a, b = image_point(start), image_point(end)
    unit = (b - a) / np.linalg.norm(b - a)
    normal = np.array([-unit[1], unit[0], 0.0])
    line = Line(a, b, color=INK, stroke_width=1.8)
    caps = VGroup(*[Line(p - 0.08 * normal, p + 0.08 * normal, color=INK, stroke_width=1.8) for p in [a, b]])
    label = caption(text, label_position[0], label_position[1] + IMAGE_TOP, size=30, backing=True)
    return VGroup(line, caps, label).set_z_index(5)


def build_diagram():
    background = ImageMobject(str(BACKGROUND)).set_width(config.frame_width)
    background.move_to(canvas_point(1086, IMAGE_TOP + 362)).set_z_index(0)
    headers = VGroup(caption("(a) Apparatus", 510, 32, size=34), caption("(b) Plan view", 1750, 32, size=34))
    labels = VGroup()
    specifications = [
        ("Laser", (115, 141), (124, 221)),
        ("S", (310, 143), (308, 224)),
        ("M", (498, 175), (484, 259)),
        ("C", (684, 218), (682, 315)),
        ("M₁ (movable)", (930, 32), (779, 77)),
        ("M₂ (fixed)", (1004, 316), (841, 380)),
        ("Screen", (165, 528), (288, 506)),
        ("Laser", (1370, 239), (1378, 331)),
        ("S", (1538, 239), (1549, 317)),
        ("M", (1665, 472), (1721, 399)),
        ("C", (1944, 494), (1911, 397)),
        ("M₁ (movable)", (1900, 29), (1807, 145)),
        ("M₂ (fixed)", (2020, 497), (2089, 419)),
        ("Screen", (1614, 608), (1735, 589)),
    ]
    for text, location, target in specifications:
        labels.add(component_label(text, location, target))

    incident = VGroup()
    outward = VGroup()
    returning = VGroup()
    output = VGroup()
    paths = {"incident": [], "outward": [], "returning": [], "output": []}
    for panel in PANELS:
        s, b, m1, m2, screen = [image_point(panel[key]) for key in ["source", "splitter", "m1", "m2", "screen"]]
        incident.add(ray_line(s, b, INCIDENT), direction_arrow(s, b, 0.64, INCIDENT))
        paths["incident"].append((s, b, INCIDENT))
        for mirror, color in [(m1, TEAL), (m2, RED_PATH)]:
            outward.add(ray_line(b, mirror, color), direction_arrow(b, mirror, 0.32, color))
            returning.add(direction_arrow(b, mirror, 0.72, color, forward=False))
            paths["outward"].append((b, mirror, color))
            paths["returning"].append((mirror, b, color))
        # The two output rays overlap physically. A 7-pixel display separation
        # makes both path colors visible; the caption states this convention.
        direction = (screen - b) / np.linalg.norm(screen - b)
        normal = np.array([-direction[1], direction[0], 0.0])
        for offset, color in [(-0.035, TEAL), (0.035, RED_PATH)]:
            a, z = b + offset * normal, screen + offset * normal
            output.add(ray_line(a, z, color), direction_arrow(a, z, 0.72, color))
            paths["output"].append((a, z, color))

    dimensions = VGroup(dimension((1645, 151), (1645, 365), "d₁", (1609, 258)), dimension((1769, 238), (2088, 238), "d₂", (1928, 208)))
    # Extension lines align each bracket with the actual reflecting surface.
    for a, b in [((1645, 151), (1740, 151)), ((1645, 365), (1725, 365)), ((1769, 238), (1769, 275)), ((2088, 238), (2088, 280))]:
        dimensions.add(DashedLine(image_point(a), image_point(b), color=INK, stroke_width=1.1, dash_length=0.04))

    legend = VGroup(caption("S: source diffuser", 360, 870, size=27), caption("M: beam splitter", 1060, 870, size=27), caption("C: compensator", 1780, 870, size=27), caption("M₁ path", 620, 916, size=26, color=TEAL), caption("M₂ path", 1510, 916, size=26, color=RED_PATH), caption("Colors identify paths, not wavelengths. Output rays are separated slightly for visibility.", 1086, 960, size=23), caption("Staged ray tracing; dimensions and travel times are not to scale.", 1086, 994, size=21))
    return dict(background=background, headers=headers, labels=labels, incident=incident, outward=outward, returning=returning, output=output, dimensions=dimensions, legend=legend, paths=paths)


class MichelsonFigure(Scene):
    """Static replacement and poster with exactly the animation's final layout."""
    def construct(self):
        diagram = build_diagram()
        for key in ["background", "headers", "labels", "incident", "outward", "returning", "output", "dimensions", "legend"]:
            self.add(diagram[key])
        self.add(caption("Light splits, reflects, and recombines at the screen", 1086, 84, size=28))


class MichelsonOverlay(Scene):
    def construct(self):
        diagram = build_diagram()
        self.add(diagram["background"], diagram["headers"], diagram["legend"])
        status = caption("Identify the source, mirrors, beam splitter, and screen", 1086, 84, size=28)
        self.add(status)
        self.play(FadeIn(diagram["labels"]), run_time=1.5)
        self.wait(1.5)

        def stage(key, message, duration):
            nonlocal status
            new_status = caption(message, 1086, 84, size=28)
            self.play(ReplacementTransform(status, new_status), FadeIn(diagram[key]), run_time=0.6)
            status = new_status
            pulses = [Dot(start, radius=0.065, color=color, stroke_color=WHITE, stroke_width=1.5).set_z_index(8) for start, end, color in diagram["paths"][key]]
            self.add(*pulses)
            animations = [MoveAlongPath(dot, Line(start, end), rate_func=linear) for dot, (start, end, color) in zip(pulses, diagram["paths"][key])]
            self.play(*animations, run_time=duration)
            self.remove(*pulses)
            self.wait(0.6)

        stage("incident", "Light passes through S and reaches the beam splitter M", 2.0)
        stage("outward", "M reflects one part toward M₁ and transmits the other toward M₂", 2.8)
        stage("returning", "Both mirrors reflect the light back toward M", 2.8)
        stage("output", "The returning beams overlap on their way to the screen", 2.5)
        final_status = caption("Light splits, reflects, and recombines at the screen", 1086, 84, size=28)
        self.play(ReplacementTransform(status, final_status), FadeIn(diagram["dimensions"]), run_time=1.0)
        self.wait(4)
